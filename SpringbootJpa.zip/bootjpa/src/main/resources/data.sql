insert into alien values(101,'chaitanya','java');
insert into alien values(102,'jhon snow','sql');
insert into alien values(103,'otis','python');
insert into alien values(104,'meave','cloud');
insert into alien values(105,'tarun balaji','sql');